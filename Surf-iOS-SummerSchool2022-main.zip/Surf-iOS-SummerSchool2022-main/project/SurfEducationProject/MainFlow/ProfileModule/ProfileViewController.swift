//
//  ProfileViewController.swift
//  SurfEducationProject
//
//  Created by Malygin Georgii on 03.08.2022.
//

import UIKit

final class ProfileViewController: UIViewController {

    // MARK: - Lifeсyrcle

    override func viewDidLoad() {
        super.viewDidLoad()        
    }

}
