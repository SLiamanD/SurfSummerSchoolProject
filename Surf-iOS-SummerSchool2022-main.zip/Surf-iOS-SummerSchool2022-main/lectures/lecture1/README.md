# Материалы

* [Подробно о Xcode](https://developer.apple.com/library/archive/documentation/ToolsLanguages/Conceptual/Xcode_Overview/index.html#//apple_ref/doc/uid/TP40010215-CH24-SW1)
* [Подробно о Interface Builder](https://developer.apple.com/library/archive/documentation/ToolsLanguages/Conceptual/Xcode_Overview/UsingInterfaceBuilder.html#//apple_ref/doc/uid/TP40010215-CH5)
* [Короткая вводная по Git](https://tproger.ru/translations/git-quick-start/)
* [Hotkey](https://it-guru.kz/swift_blog/goryachie-klavishi-xcode/)
* [Жизненный цикл приложения на русском](https://proswift.ru/ios-application-lifecycle-ili-zhiznennyj-cikl-ios-prilozheniya/)
* [Туториал по Storyboard от Ray Wenderlich](https://www.raywenderlich.com/160521/storyboards-tutorial-ios-11-part-1)
* [UIApplicationDelegate](https://developer.apple.com/documentation/uikit/uiapplicationdelegate)
* [UIScene Документация Apple](https://developer.apple.com/documentation/uikit/uiscene)
* [Документация c подробным пояснением](https://git-scm.com/docs)
* [Короткая вводная на русском](https://tproger.ru/translations/git-quick-start/)
* [Более подробно на русском](https://ru.hexlet.io/courses/intro_to_git)
