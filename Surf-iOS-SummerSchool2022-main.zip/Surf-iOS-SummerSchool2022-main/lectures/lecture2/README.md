# Материалы

* [Документация Apple UIViewController](https://developer.apple.com/documentation/uikit/view_controllers)
* [Статья Хабр про жизненный цикл UIViewController](https://habr.com/ru/post/129557/)
* [Документация Apple UINavigationController](https://developer.apple.com/documentation/uikit/uinavigationcontroller)
* [Документация Apple UITabBarController](https://developer.apple.com/documentation/uikit/uitabbarcontroller)
* [Основы мобильной навигации](https://vc.ru/flood/24327-navigationpatterns)
* [UI/UX Design Glossary. Navigation Elements](https://uxplanet.org/ui-ux-design-glossary-navigation-elements-b552130711c8)
