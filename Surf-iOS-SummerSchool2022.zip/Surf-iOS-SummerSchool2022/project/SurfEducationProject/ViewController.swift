//
//  ViewController.swift
//  SurfEducationProject
//
//  Created by Malygin Georgii on 02.08.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

